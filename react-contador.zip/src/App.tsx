import React from 'react';
import Technologies from "./components/Technologies";
import logo from './logo.svg';

import './App.css';

function App() {
  return (
    <>
    <h1>Seja bem vindo aos testes</h1>
    <Technologies />
    </>
  );
}

export default App;
