import React from 'react';
import { render, screen } from '@testing-library/react';
import App from './App';
import Technologies from './components/Technologies';

describe('App', () => {
test('renders learn react link', () => {
  render(<Technologies />);
  screen.debug();
  });  
});

